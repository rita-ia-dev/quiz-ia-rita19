import flet as ft
import time

def main(page: ft.Page):
    # --- 1. CONFIGURAÇÕES INICIAIS ---
    page.title = "IA Quiz - Rita"
    page.bgcolor = "#1a1a2e"
    page.theme_mode = ft.ThemeMode.DARK
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER 
    
    placar = {"pontos": 0}
    msg = ft.Text("", size=18, weight="bold")

    # --- 2. FUNÇÕES DE LÓGICA (ERRO E ACERTO) ---
    def proxima_com_erro(e, proxima_fase):
        msg.value = "❌ Errou! Vamos para a próxima..."
        msg.color = "red"
        # 1. Primeiro, mandamos o Flet desenhar a mensagem na tela
        page.update() 
        
        # 2. Agora mandamos o Python esperar 1.5 segundos (a tela fica 'parada' aqui)
        import time
        time.sleep(1.5) 
        
        # 3. Só agora limpamos a mensagem e mudamos de tela
        msg.value = ""
        proxima_fase(None)

    def proxima_com_acerto(e, proxima_fase):
        placar["pontos"] += 1
        proxima_fase(None)

    # --- 3. TELAS DAS PERGUNTAS (ORDEM INVERSA PARA EVITAR ERROS) ---

    def tela_vitoria(e):
        page.clean()
        page.add(
            ft.Text("🏆 FIM DO DESAFIO!", size=40, color="orange", weight="bold"),
            ft.Text(f"Sua pontuação final: {placar['pontos']} de 5", size=25),
            ft.ElevatedButton("Recomeçar", on_click=lambda _: iniciar_quiz())
        )

    # --- PERGUNTAS EMBARALHADAS ---

    def p5(e):
        page.clean()
        msg.value = ""
        page.add(
            ft.Text("Pergunta 5/5", size=16, color="blue"),
            ft.Text("O que é uma 'alucinação' na IA?", size=26, weight="bold", text_align="center"),
            ft.ElevatedButton("O computador esquenta demais", on_click=lambda e: proxima_com_erro(e, tela_vitoria), width=320),
            ft.ElevatedButton("IA inventa fatos falsos", on_click=lambda e: proxima_com_acerto(e, tela_vitoria), width=320), # CORRETA NO MEIO
            ft.ElevatedButton("A IA fica com sono", on_click=lambda e: proxima_com_erro(e, tela_vitoria), width=320),
            msg
        )

    def p4(e):
        page.clean()
        msg.value = ""
        page.add(
            ft.Text("Pergunta 4/5", size=16, color="blue"),
            ft.Text("A IA substituirá todos os empregos?", size=26, weight="bold", text_align="center"),
            ft.ElevatedButton("Sim, em breve", on_click=lambda e: proxima_com_erro(e, p5), width=320),
            ft.ElevatedButton("IA não serve para trabalhar", on_click=lambda e: proxima_com_erro(e, p5), width=320),
            ft.ElevatedButton("Não, será ferramenta de apoio", on_click=lambda e: proxima_com_acerto(e, p5), width=320), # CORRETA NO FIM
            msg
        )

    def p3(e):
        page.clean()
        msg.value = ""
        page.add(
            ft.Text("Pergunta 3/5", size=16, color="blue"),
            ft.Text("A IA pode sentir emoções?", size=26, weight="bold", text_align="center"),
            ft.ElevatedButton("Sim, ela tem coração", on_click=lambda e: proxima_com_erro(e, p4), width=320),
            ft.ElevatedButton("Não, ela processa cálculos", on_click=lambda e: proxima_com_acerto(e, p4), width=320), # CORRETA NO MEIO
            ft.ElevatedButton("Só quando está triste", on_click=lambda e: proxima_com_erro(e, p4), width=320),
            msg
        )

    def p2(e):
        page.clean()
        msg.value = ""
        page.add(
            ft.Text("Pergunta 2/5", size=16, color="blue"),
            ft.Text("O que é IA Generativa?", size=26, weight="bold", text_align="center"),
            ft.ElevatedButton("Um antivírus", on_click=lambda e: proxima_com_erro(e, p3), width=320),
            ft.ElevatedButton("Um robô doméstico", on_click=lambda e: proxima_com_erro(e, p3), width=320),
            ft.ElevatedButton("IA que cria conteúdos novos", on_click=lambda e: proxima_com_acerto(e, p3), width=320), # CORRETA NO FIM
            msg
        )

    def p1(e):
        page.clean()
        msg.value = ""
        page.add(
            ft.Text("Pergunta 1/5", size=16, color="blue"),
            ft.Text("Qual o 'combustível' da IA?", size=26, weight="bold", text_align="center"),
            ft.ElevatedButton("Dados e Informações", on_click=lambda e: proxima_com_acerto(e, p2), width=320), # CORRETA NO INÍCIO
            ft.ElevatedButton("Gasolina", on_click=lambda e: proxima_com_erro(e, p2), width=320),
            ft.ElevatedButton("Pilhas", on_click=lambda e: proxima_com_erro(e, p2), width=320),
            msg
        )

    # --- 4. TELA INICIAL ---
    def iniciar_quiz():
        page.clean()
        placar["pontos"] = 0
        page.add(
            ft.Text("QUIZ DE EXTENSÃO", size=32, weight="bold"),
            ft.Text("Inteligência Artificial", size=18, color="white70"),
            ft.Divider(height=20, color="transparent"),
            ft.ElevatedButton("INICIAR DESAFIO", on_click=lambda _: p1(None), width=220, height=50)
        )

    iniciar_quiz()

# --- 5. EXECUÇÃO DO APP ---
ft.app(target=main)